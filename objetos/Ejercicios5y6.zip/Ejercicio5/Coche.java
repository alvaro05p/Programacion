public class Coche extends Vehiculo {
    
    public Coche(){


    }

}