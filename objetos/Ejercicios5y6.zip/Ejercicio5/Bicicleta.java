public class Bicicleta extends Vehiculo{

    private int kilometrosRecorridos;

    public Bicicleta(){

        this.kilometrosRecorridos=kilometrosRecorridos;

    }

    public int masKmBici (int km){

        kilometrosRecorridos+=km;

        return kilometrosRecorridos;

    }



}