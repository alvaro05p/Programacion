public class Vehiculo{


    private int vehiculosCreados=0;
    private int kilometrosTotales=0;
    static int kilometrosRecorridos=0;

    public Vehiculo(){

        this.vehiculosCreados=vehiculosCreados;
        this.kilometrosTotales=kilometrosTotales;
        this.kilometrosRecorridos=kilometrosRecorridos;

    }



    
}